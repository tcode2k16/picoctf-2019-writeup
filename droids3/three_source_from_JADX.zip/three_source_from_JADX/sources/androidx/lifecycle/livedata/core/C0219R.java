package androidx.lifecycle.livedata.core;

/* renamed from: androidx.lifecycle.livedata.core.R */
public final class C0219R {
    private C0219R() {
    }
}
