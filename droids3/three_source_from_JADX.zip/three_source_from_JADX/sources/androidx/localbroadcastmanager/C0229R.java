package androidx.localbroadcastmanager;

/* renamed from: androidx.localbroadcastmanager.R */
public final class C0229R {
    private C0229R() {
    }
}
